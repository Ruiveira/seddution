# Integração do Stripe - AI NSFW Generator

## Visão Geral

Este documento descreve a integração dos links de pagamento do Stripe no site AI NSFW Generator. A integração permite que os usuários assinem planos de serviço nas modalidades mensal, trimestral e anual.

## Mudanças Realizadas

### 1. Nova Página de Preços (`client/src/pages/Pricing.tsx`)

Uma nova página foi criada para exibir os planos de assinatura disponíveis. A página inclui:

- **Três planos de assinatura:**
  - **Mensal**: R$ 29,90 por mês
  - **Trimestral**: R$ 74,90 a cada 3 meses (16% de desconto)
  - **Anual**: R$ 238,80 por ano (33% de desconto)

- **Características da página:**
  - Cards de preços responsivos com design neon
  - Destaque do plano mais popular (Trimestral)
  - Seção de FAQ (Perguntas Frequentes)
  - Links diretos para checkout do Stripe
  - Navegação integrada com o resto do site

### 2. Links de Pagamento do Stripe

Os seguintes links de checkout foram integrados:

| Plano | Preço | Link |
|-------|-------|------|
| Mensal | R$ 29,90 | https://buy.stripe.com/7sYbITfD4aLV7ur9TV4c80z |
| Trimestral | R$ 74,90 | https://buy.stripe.com/00wdR19eGbPZ5mj1np4c80A |
| Anual | R$ 238,80 | https://buy.stripe.com/28E00b76y8DN7ur4zB4c80B |

### 3. Atualização das Rotas (`client/src/App.tsx`)

A rota `/pricing` foi adicionada ao sistema de roteamento da aplicação:

```typescript
<Route path="/pricing" component={Pricing} />
```

### 4. Integração de Navegação

Botões "Planos" foram adicionados em todas as páginas principais:

- **Home.tsx**: Botão "Ver Planos" para usuários não autenticados e "Planos" para usuários autenticados
- **Generator.tsx**: Botão "Planos" no header
- **Gallery.tsx**: Botão "Planos" no header

## Fluxo de Assinatura

1. **Usuário não autenticado**: Clica em "Ver Planos" → É redirecionado para fazer login → Volta para página de preços
2. **Usuário autenticado**: Clica em "Planos" → Vê os planos disponíveis → Clica em "Assinar Agora" → É redirecionado para o Stripe
3. **No Stripe**: Usuário completa o pagamento e retorna ao site

## Funcionalidades da Página de Preços

### Componentes Principais

1. **Header**: Navegação consistente com o resto do site
2. **Hero Section**: Título e descrição dos planos
3. **Cards de Preços**: Exibem informações de cada plano com:
   - Ícone representativo
   - Nome e descrição do plano
   - Preço e período de faturamento
   - Lista de features incluídas
   - Botão de ação (Assinar Agora)
4. **Seção de FAQ**: Respostas às perguntas mais frequentes
5. **CTA Section**: Chamada para ação para ir ao gerador
6. **Footer**: Links de navegação rápida

### Design e Estilo

- **Tema**: Neon-noir com cores primárias (rosa neon e cyan)
- **Responsividade**: Totalmente responsivo para mobile, tablet e desktop
- **Animações**: Hover effects nos cards e transições suaves
- **Acessibilidade**: Estrutura semântica e contraste adequado

## Comportamento dos Botões

### Botão "Assinar Agora"

- **Se usuário não autenticado**: Redireciona para login
- **Se usuário autenticado**: Abre o link de checkout do Stripe em uma nova aba

### Navegação

- Todos os botões de navegação mantêm consistência com o design existente
- Links internos usam `setLocation()` do Wouter
- Links externos (Stripe) abrem em nova aba com `window.open()`

## Estrutura de Dados

Os planos são definidos em um array `PRICING_PLANS` com a seguinte estrutura:

```typescript
{
  id: string;              // Identificador único do plano
  name: string;            // Nome do plano
  price: string;           // Preço formatado
  period: string;          // Período de faturamento
  description: string;     // Descrição curta
  features: string[];      // Array de features incluídas
  icon: IconComponent;     // Ícone do Lucide React
  stripeUrl: string;       // URL de checkout do Stripe
  highlighted: boolean;    // Se é o plano destacado
}
```

## Integração com Autenticação

A página verifica o estado de autenticação do usuário:

```typescript
const { user, loading } = useAuth();
```

- Se o usuário não está autenticado e clica em "Assinar Agora", é redirecionado para login
- Se o usuário está autenticado, pode proceder direto para o Stripe

## Próximos Passos Recomendados

1. **Backend Integration**: Implementar webhooks do Stripe para:
   - Confirmar pagamentos
   - Atualizar status de assinatura no banco de dados
   - Adicionar/renovar créditos do usuário

2. **Gerenciamento de Assinatura**: Criar página para:
   - Visualizar assinatura ativa
   - Gerenciar método de pagamento
   - Cancelar assinatura

3. **Sistema de Créditos**: Implementar lógica para:
   - Renovar créditos mensalmente baseado no plano
   - Rastrear uso de créditos
   - Mostrar histórico de transações

4. **Notificações**: Adicionar:
   - Email de confirmação de assinatura
   - Alertas quando créditos estão acabando
   - Notificações de renovação

5. **Testes**: 
   - Testar fluxo completo de assinatura
   - Validar links do Stripe
   - Testar responsividade em diferentes dispositivos

## Troubleshooting

### Links do Stripe não funcionam
- Verificar se os links estão corretos na constante `PRICING_PLANS`
- Testar os links diretamente no navegador
- Verificar se a conta do Stripe está ativa

### Botões não redirecionam
- Verificar se `useAuth()` está retornando corretamente o estado do usuário
- Verificar console do navegador para erros
- Verificar se `useLocation()` do Wouter está funcionando

### Design não aparece correto
- Limpar cache do navegador
- Verificar se os estilos CSS do `index.css` estão sendo aplicados
- Verificar se as classes Tailwind estão sendo compiladas

## Arquivos Modificados

- ✅ `client/src/App.tsx` - Adicionada rota `/pricing`
- ✅ `client/src/pages/Pricing.tsx` - Nova página de preços
- ✅ `client/src/pages/Home.tsx` - Adicionados botões de navegação para preços
- ✅ `client/src/pages/Generator.tsx` - Adicionado botão de preços no header
- ✅ `client/src/pages/Gallery.tsx` - Adicionado botão de preços no header

## Suporte

Para questões sobre a integração do Stripe ou para implementar funcionalidades adicionais, consulte:

- [Documentação do Stripe](https://stripe.com/docs)
- [Documentação do Wouter](https://github.com/molefrog/wouter)
- [Documentação do React](https://react.dev)
