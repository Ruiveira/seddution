import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { addCredits, consumeCredits, getUserCredits, initializeUserCredits, upsertUser } from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("Credits System", () => {
  describe("credits.get", () => {
    it("should initialize credits for new user", async () => {
      const openId = `test-user-init-${Date.now()}`;
      
      // Create user first
      await upsertUser({
        openId,
        name: "Test User Init",
        email: "testinit@example.com",
      });
      
      // Get the actual user
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      const ctx = createAuthContext(user.id);
      ctx.user!.openId = openId;
      const caller = appRouter.createCaller(ctx);

      const credits = await caller.credits.get();

      expect(credits).toBeDefined();
      expect(credits?.credits).toBe(10); // Default initial credits
      expect(credits?.userId).toBe(user.id);
    });

    it("should return existing credits for user", async () => {
      const openId = `test-user-existing-${Date.now()}`;
      
      // Create user first
      await upsertUser({
        openId,
        name: "Test User Existing",
        email: "testexisting@example.com",
      });
      
      // Get the actual user
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      const ctx = createAuthContext(user.id);
      ctx.user!.openId = openId;
      const caller = appRouter.createCaller(ctx);

      // First call initializes
      await caller.credits.get();

      // Second call should return same credits
      const credits = await caller.credits.get();

      expect(credits).toBeDefined();
      expect(credits?.credits).toBe(10);
    });
  });

  describe("credits.add", () => {
    it("should add credits to user account", async () => {
      const openId = `test-user-add-credits-${Date.now()}`;
      
      // Create user first
      await upsertUser({
        openId,
        name: "Test User Add Credits",
        email: "testaddcredits@example.com",
      });
      
      // Get the actual user
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      const ctx = createAuthContext(user.id);
      ctx.user!.openId = openId;
      const caller = appRouter.createCaller(ctx);

      // Initialize
      await caller.credits.get();

      // Add credits
      const updated = await caller.credits.add({ amount: 5 });

      expect(updated).toBeDefined();
      expect(updated?.credits).toBe(15); // 10 initial + 5 added
    });

    it("should reject negative amounts", async () => {
      const openId = `test-user-negative-${Date.now()}`;
      
      await upsertUser({
        openId,
        name: "Test User Negative",
        email: "testnegative@example.com",
      });
      
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      const ctx = createAuthContext(user.id);
      ctx.user!.openId = openId;
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.credits.add({ amount: -5 })
      ).rejects.toThrow();
    });

    it("should reject amounts over 1000", async () => {
      const openId = `test-user-overlimit-${Date.now()}`;
      
      await upsertUser({
        openId,
        name: "Test User Over Limit",
        email: "testoverlimit@example.com",
      });
      
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      const ctx = createAuthContext(user.id);
      ctx.user!.openId = openId;
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.credits.add({ amount: 1001 })
      ).rejects.toThrow();
    });
  });

  describe("Database functions", () => {
    it("should consume credits correctly", async () => {
      const openId = `test-user-consume-${Date.now()}`;
      
      // Create user first (foreign key requirement)
      await upsertUser({
        openId,
        name: `Test User Consume`,
        email: `testconsume@example.com`,
      });
      
      // Get the actual user ID from database
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      // Initialize with credits
      await initializeUserCredits(user.id, 10);

      // Consume 1 credit
      const success = await consumeCredits(user.id, 1);
      expect(success).toBe(true);

      // Check remaining
      const credits = await getUserCredits(user.id);
      expect(credits?.credits).toBe(9);
    });

    it("should fail to consume when insufficient credits", async () => {
      const openId = `test-user-insufficient-${Date.now()}`;
      
      // Create user first
      await upsertUser({
        openId,
        name: `Test User Insufficient`,
        email: `testinsufficient@example.com`,
      });
      
      // Get the actual user ID
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      // Initialize with 2 credits
      await initializeUserCredits(user.id, 2);

      // Try to consume 3 credits
      const success = await consumeCredits(user.id, 3);
      expect(success).toBe(false);

      // Credits should remain unchanged
      const credits = await getUserCredits(user.id);
      expect(credits?.credits).toBe(2);
    });

    it("should add credits to existing user", async () => {
      const openId = `test-user-add-${Date.now()}`;
      
      // Create user first
      await upsertUser({
        openId,
        name: `Test User Add`,
        email: `testadd@example.com`,
      });
      
      // Get the actual user ID
      const { getUserByOpenId } = await import("./db");
      const user = await getUserByOpenId(openId);
      if (!user) throw new Error("User not found");
      
      // Initialize
      await initializeUserCredits(user.id, 5);

      // Add more credits
      await addCredits(user.id, 10);

      // Check total
      const credits = await getUserCredits(user.id);
      expect(credits?.credits).toBe(15);
    });
  });
});
