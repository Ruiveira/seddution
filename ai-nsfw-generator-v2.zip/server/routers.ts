import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { addCredits, consumeCredits, getUserCredits, getUserGenerations, initializeUserCredits, saveImageGeneration } from "./db";
import { generateImage } from "./_core/imageGeneration";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  credits: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      let credits = await getUserCredits(ctx.user.id);
      
      // Initialize credits if user doesn't have any yet
      if (!credits) {
        credits = await initializeUserCredits(ctx.user.id, 10);
      }
      
      return credits;
    }),
    
    add: protectedProcedure
      .input(z.object({ amount: z.number().min(1).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const updated = await addCredits(ctx.user.id, input.amount);
        return updated;
      }),
  }),

  generator: router({
    generate: protectedProcedure
      .input(z.object({ prompt: z.string().min(1).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        // Check if user has enough credits
        const credits = await getUserCredits(ctx.user.id);
        if (!credits || credits.credits < 1) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Créditos insuficientes. Você precisa de pelo menos 1 crédito para gerar uma imagem.",
          });
        }

        // Consume credits before generation
        const consumed = await consumeCredits(ctx.user.id, 1);
        if (!consumed) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Falha ao consumir créditos. Tente novamente.",
          });
        }

        try {
          // Generate image using AI (already uploads to S3)
          const result = await generateImage({
            prompt: input.prompt,
          });

          if (!result.url) {
            throw new Error("Image generation returned no URL");
          }

          const s3Url = result.url;
          const fileKey = `generations/${ctx.user.id}/${nanoid()}.png`;

          // Save generation to database
          const generation = await saveImageGeneration({
            userId: ctx.user.id,
            prompt: input.prompt,
            imageUrl: s3Url,
            imageKey: fileKey,
            creditsUsed: 1,
          });

          return {
            success: true,
            imageUrl: s3Url,
            generation,
          };
        } catch (error) {
          // Refund credits on failure
          await addCredits(ctx.user.id, 1);
          
          console.error("[Generator] Image generation failed:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Falha ao gerar imagem. Seus créditos foram reembolsados.",
          });
        }
      }),

    history: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(100).optional().default(50) }))
      .query(async ({ ctx, input }) => {
        const generations = await getUserGenerations(ctx.user.id, input.limit);
        return generations;
      }),
  }),
});

export type AppRouter = typeof appRouter;
