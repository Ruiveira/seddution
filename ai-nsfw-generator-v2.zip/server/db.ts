import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { ImageGeneration, imageGenerations, InsertImageGeneration, InsertUser, InsertUserCredits, userCredits, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Credits Management
export async function getUserCredits(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user credits: database not available");
    return null;
  }

  const result = await db.select().from(userCredits).where(eq(userCredits.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function initializeUserCredits(userId: number, initialCredits: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot initialize credits: database not available");
    return null;
  }

  const values: InsertUserCredits = {
    userId,
    credits: initialCredits,
  };

  await db.insert(userCredits).values(values);
  return await getUserCredits(userId);
}

export async function consumeCredits(userId: number, amount: number = 1) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot consume credits: database not available");
    return false;
  }

  const current = await getUserCredits(userId);
  if (!current || current.credits < amount) {
    return false;
  }

  await db
    .update(userCredits)
    .set({ credits: current.credits - amount })
    .where(eq(userCredits.userId, userId));

  return true;
}

export async function addCredits(userId: number, amount: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add credits: database not available");
    return null;
  }

  const current = await getUserCredits(userId);
  if (!current) {
    return await initializeUserCredits(userId, amount);
  }

  await db
    .update(userCredits)
    .set({ credits: current.credits + amount })
    .where(eq(userCredits.userId, userId));

  return await getUserCredits(userId);
}

// Image Generations Management
export async function saveImageGeneration(data: InsertImageGeneration): Promise<ImageGeneration | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save image generation: database not available");
    return null;
  }

  const result = await db.insert(imageGenerations).values(data);
  const insertId = Number(result[0].insertId);
  
  const saved = await db.select().from(imageGenerations).where(eq(imageGenerations.id, insertId)).limit(1);
  return saved.length > 0 ? saved[0] : null;
}

export async function getUserGenerations(userId: number, limit: number = 50): Promise<ImageGeneration[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user generations: database not available");
    return [];
  }

  return await db
    .select()
    .from(imageGenerations)
    .where(eq(imageGenerations.userId, userId))
    .orderBy(desc(imageGenerations.createdAt))
    .limit(limit);
}
