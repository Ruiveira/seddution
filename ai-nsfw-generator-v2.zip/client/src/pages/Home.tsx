import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Image as ImageIcon, Zap, Shield, Coins } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { trpc } from "@/lib/trpc";

const AGE_VERIFICATION_KEY = "age_verified";

export default function Home() {
  const { user, loading, logout } = useAuth();
  const [, setLocation] = useLocation();

  const { data: credits } = trpc.credits.get.useQuery(undefined, {
    enabled: !!user,
  });

  useEffect(() => {
    // Check age verification
    const verified = localStorage.getItem(AGE_VERIFICATION_KEY);
    if (verified !== "true") {
      setLocation("/age-verification");
    }
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Accent Lines */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-[oklch(0.75_0.2_200)] to-transparent opacity-60"></div>
        <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-[oklch(0.65_0.28_320)] to-transparent opacity-60"></div>
        
        <div className="container py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-5xl md:text-7xl font-black neon-glow-pink tracking-tight">
              AI NSFW Generator
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground font-light tracking-wide">
              Crie conteúdo visual adulto personalizado usando inteligência artificial de última geração
            </p>
            
            {loading ? (
              <div className="flex justify-center">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : user ? (
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  size="lg"
                  onClick={() => setLocation("/generator")}
                  className="text-lg px-8 h-14 neon-border-pink font-semibold"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Gerar Imagem
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setLocation("/gallery")}
                  className="text-lg px-8 h-14"
                >
                  <ImageIcon className="w-5 h-5 mr-2" />
                  Minha Galeria
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setLocation("/pricing")}
                  className="text-lg px-8 h-14"
                >
                  Planos
                </Button>
                <div className="flex items-center gap-2 px-6 py-3 rounded-lg bg-card border border-primary/30 neon-border-pink">
                  <Coins className="w-5 h-5 text-primary" />
                  <span className="font-semibold text-primary text-lg">
                    {credits?.credits ?? 0}
                  </span>
                  <span className="text-sm text-muted-foreground">créditos</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  onClick={() => window.location.href = getLoginUrl()}
                  className="text-lg px-8 h-14 neon-border-pink font-semibold"
                >
                  Entrar / Cadastrar
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setLocation("/pricing")}
                  className="text-lg px-8 h-14"
                >
                  Ver Planos
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 neon-glow-cyan">
            Como Funciona
          </h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="border-primary/20 bg-card/50">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Descreva sua Visão</CardTitle>
                <CardDescription>
                  Digite um prompt detalhado descrevendo a imagem que você deseja criar
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-accent/20 bg-card/50">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>IA Gera a Imagem</CardTitle>
                <CardDescription>
                  Nossa IA de última geração cria conteúdo visual personalizado em segundos
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-primary/20 bg-card/50">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <ImageIcon className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Salve e Explore</CardTitle>
                <CardDescription>
                  Visualize, baixe e gerencie todas suas criações na galeria pessoal
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Safety Section */}
      <section className="py-20">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <Card className="border-destructive/30 bg-card/50">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="w-8 h-8 text-destructive" />
                  <CardTitle className="text-2xl">Uso Responsável</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Esta plataforma é destinada exclusivamente a adultos maiores de 18 anos.
                  Todo conteúdo é gerado por IA e não representa pessoas reais.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-muted-foreground">
                <p>• Proibido gerar conteúdo envolvendo menores de idade</p>
                <p>• Proibido criar conteúdo ilegal ou que viole direitos de terceiros</p>
                <p>• Você é responsável pelo uso apropriado desta ferramenta</p>
                <p className="pt-3">
                  <button
                    onClick={() => setLocation("/terms")}
                    className="text-primary hover:underline font-semibold"
                  >
                    Leia os Termos de Uso completos →
                  </button>
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 bg-card/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} AI NSFW Generator. Todos os direitos reservados.
            </p>
            <div className="flex gap-6">
              <button
                onClick={() => setLocation("/terms")}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Termos de Uso
              </button>
              {user && (
                <button
                  onClick={() => logout()}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  Sair
                </button>
              )}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
