import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Zap, Crown, Sparkles, ShieldCheck, Rocket, Diamond } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Frequency = "monthly" | "quarterly" | "semiannual" | "annual";

const STRIPE_LINKS = {
  monthly: "https://buy.stripe.com/7sYbITfD4aLV7ur9TV4c80z",
  quarterly: "https://buy.stripe.com/00wdR19eGbPZ5mj1np4c80A",
  annual: "https://buy.stripe.com/28E00b76y8DN7ur4zB4c80B",
  // Usando o anual como fallback para semestral por enquanto, conforme instrução de usar os links passados
  semiannual: "https://buy.stripe.com/28E00b76y8DN7ur4zB4c80B",
};

const PRICING_PLANS = [
  {
    id: "pro",
    name: "Pro",
    icon: Rocket,
    description: "Ideal para entusiastas e criadores ocasionais.",
    highlighted: false,
    features: [
      "500 créditos por mês",
      "Geração em alta velocidade",
      "Acesso a modelos básicos",
      "Suporte via email",
      "Galeria privada",
    ],
    prices: {
      monthly: "R$ 29,90",
      quarterly: "R$ 74,90",
      semiannual: "R$ 139,90",
      annual: "R$ 238,80",
    }
  },
  {
    id: "platinum",
    name: "Platinum",
    icon: Crown,
    description: "Para usuários avançados que buscam qualidade superior.",
    highlighted: true,
    features: [
      "2.000 créditos por mês",
      "Prioridade máxima na fila",
      "Modelos Ultra-Realistas",
      "Suporte prioritário 24/7",
      "Sem marca d'água",
      "Acesso antecipado a novas ferramentas",
    ],
    prices: {
      monthly: "R$ 59,90",
      quarterly: "R$ 149,90",
      semiannual: "R$ 279,90",
      annual: "R$ 479,90",
    }
  },
  {
    id: "diamond",
    name: "Diamond",
    icon: Diamond,
    description: "A experiência definitiva sem limites.",
    highlighted: false,
    features: [
      "Créditos Ilimitados",
      "Servidor Dedicado para Geração",
      "Todos os Modelos Premium",
      "Gerente de conta VIP",
      "Direitos comerciais das imagens",
      "API de acesso direto",
      "Treinamento de modelo personalizado",
    ],
    prices: {
      monthly: "R$ 129,90",
      quarterly: "R$ 329,90",
      semiannual: "R$ 599,90",
      annual: "R$ 999,90",
    }
  },
];

export default function Pricing() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [frequency, setFrequency] = useState<Frequency>("monthly");

  const handlePlanClick = () => {
    if (!user) {
      window.location.href = getLoginUrl();
      return;
    }
    // Por enquanto, redireciona para os links do Stripe fornecidos
    const url = STRIPE_LINKS[frequency] || STRIPE_LINKS.monthly;
    window.open(url, "_blank");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold neon-glow-pink">
              AI NSFW Generator
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => setLocation("/generator")}>
              Gerador
            </Button>
            <Button variant="ghost" onClick={() => setLocation("/")}>
              Início
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container max-w-6xl">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-4xl md:text-6xl font-bold neon-glow-pink">
              Planos Premium
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Escolha o nível de poder que você precisa. De criações casuais a produções profissionais ilimitadas.
            </p>
          </div>

          {/* Frequency Selector */}
          <div className="flex justify-center mb-16">
            <Tabs 
              defaultValue="monthly" 
              className="w-full max-w-md"
              onValueChange={(v) => setFrequency(v as Frequency)}
            >
              <TabsList className="grid grid-cols-4 bg-card border border-border/50">
                <TabsTrigger value="monthly">Mensal</TabsTrigger>
                <TabsTrigger value="quarterly">Trimestral</TabsTrigger>
                <TabsTrigger value="semiannual">Semestral</TabsTrigger>
                <TabsTrigger value="annual">Anual</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {PRICING_PLANS.map((plan) => {
              const Icon = plan.icon;
              return (
                <Card
                  key={plan.id}
                  className={`relative flex flex-col transition-all duration-500 hover:scale-[1.02] ${
                    plan.highlighted
                      ? "border-primary/50 bg-card/80 shadow-2xl shadow-primary/20 ring-1 ring-primary/50"
                      : "border-border/50 bg-card/50"
                  }`}
                >
                  {plan.highlighted && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="bg-primary text-primary-foreground px-6 py-1 rounded-full text-sm font-bold tracking-wider uppercase">
                        Recomendado
                      </span>
                    </div>
                  )}

                  <CardHeader className="pb-8">
                    <div className="flex items-center gap-4 mb-6">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                        plan.highlighted ? "bg-primary/20" : "bg-muted"
                      }`}>
                        <Icon className={`w-8 h-8 ${plan.highlighted ? "text-primary" : "text-muted-foreground"}`} />
                      </div>
                      <div>
                        <CardTitle className="text-3xl font-black uppercase tracking-tighter">{plan.name}</CardTitle>
                        <CardDescription className="text-sm font-medium">
                          {plan.description}
                        </CardDescription>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="text-4xl font-black text-primary flex items-baseline gap-1">
                        {plan.prices[frequency]}
                        <span className="text-sm font-normal text-muted-foreground uppercase tracking-widest">
                          / {frequency === "monthly" ? "mês" : frequency === "quarterly" ? "trimestre" : frequency === "semiannual" ? "semestre" : "ano"}
                        </span>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="flex-1 flex flex-col">
                    <div className="space-y-4 mb-10 flex-1">
                      {plan.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start gap-3 group">
                          <div className="mt-1 bg-primary/10 rounded-full p-0.5 group-hover:bg-primary/20 transition-colors">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                          </div>
                          <span className="text-sm text-foreground/90 font-medium">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Button
                      onClick={handlePlanClick}
                      size="lg"
                      className={`w-full h-14 text-lg font-bold uppercase tracking-widest transition-all duration-300 ${
                        plan.highlighted 
                          ? "neon-border-pink hover:shadow-[0_0_20px_rgba(var(--primary),0.4)]" 
                          : "hover:bg-primary hover:text-primary-foreground"
                      }`}
                      variant={plan.highlighted ? "default" : "outline"}
                    >
                      {user ? "Ativar Agora" : "Entrar para Ativar"}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Trust Badges */}
          <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-y border-border/30">
            <div className="flex flex-col items-center text-center space-y-2">
              <ShieldCheck className="w-8 h-8 text-primary" />
              <span className="text-sm font-bold uppercase tracking-tighter">Pagamento Seguro</span>
            </div>
            <div className="flex flex-col items-center text-center space-y-2">
              <Zap className="w-8 h-8 text-primary" />
              <span className="text-sm font-bold uppercase tracking-tighter">Ativação Instantânea</span>
            </div>
            <div className="flex flex-col items-center text-center space-y-2">
              <Sparkles className="w-8 h-8 text-primary" />
              <span className="text-sm font-bold uppercase tracking-tighter">Qualidade Ultra HD</span>
            </div>
            <div className="flex flex-col items-center text-center space-y-2">
              <Crown className="w-8 h-8 text-primary" />
              <span className="text-sm font-bold uppercase tracking-tighter">Suporte VIP</span>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mt-24 max-w-3xl mx-auto">
            <h3 className="text-3xl font-black text-center neon-glow-cyan mb-12 uppercase tracking-tighter">
              Dúvidas Frequentes
            </h3>
            <div className="grid gap-6">
              {[
                { q: "Como funcionam os créditos?", a: "Cada imagem gerada consome 1 crédito. No plano Diamond, você tem gerações ilimitadas sem se preocupar com contagem." },
                { q: "Posso mudar de plano depois?", a: "Sim! Você pode fazer o upgrade ou downgrade do seu plano a qualquer momento diretamente no seu painel." },
                { q: "Quais as formas de pagamento?", a: "Atualmente aceitamos cartões via Stripe. Em breve teremos suporte para Epoch, CCBill e Criptomoedas." },
                { q: "As imagens são privadas?", a: "Sim, todas as suas gerações são privadas e armazenadas em sua galeria pessoal criptografada." }
              ].map((item, i) => (
                <div key={i} className="p-6 rounded-xl bg-card/30 border border-border/50 hover:border-primary/30 transition-colors">
                  <h4 className="font-bold text-lg mb-2">{item.q}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12 bg-card/30 mt-20">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="space-y-2">
              <h4 className="text-xl font-black neon-glow-pink">AI NSFW GENERATOR</h4>
              <p className="text-xs text-muted-foreground uppercase tracking-widest">A revolução da arte adulta por IA</p>
            </div>
            <div className="flex gap-8">
              <button onClick={() => setLocation("/terms")} className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors uppercase tracking-tighter">Termos</button>
              <button onClick={() => setLocation("/")} className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors uppercase tracking-tighter">Início</button>
            </div>
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} - Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
