import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Loader2, Sparkles, Coins } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Generator() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [prompt, setPrompt] = useState("");
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const { data: credits, refetch: refetchCredits } = trpc.credits.get.useQuery(undefined, {
    enabled: !!user,
  });

  const generateMutation = trpc.generator.generate.useMutation({
    onSuccess: (data) => {
      setGeneratedImage(data.imageUrl);
      refetchCredits();
      toast.success("Imagem gerada com sucesso!");
      setPrompt("");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao gerar imagem");
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast.error("Por favor, descreva o que você quer gerar");
      return;
    }

    if (!credits || credits.credits < 1) {
      toast.error("Créditos insuficientes");
      return;
    }

    generateMutation.mutate({ prompt: prompt.trim() });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Autenticação Necessária</CardTitle>
            <CardDescription>
              Você precisa fazer login para gerar imagens
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="w-full"
            >
              Fazer Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold neon-glow-pink">
              AI NSFW Generator
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-primary/30 neon-border-pink">
              <Coins className="w-5 h-5 text-primary" />
              <span className="font-semibold text-primary">
                {credits?.credits ?? 0}
              </span>
              <span className="text-sm text-muted-foreground">créditos</span>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation("/pricing")}
            >
              Planos
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/gallery")}
            >
              Galeria
            </Button>
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
            >
              Início
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Prompt Input */}
          <div className="space-y-6 accent-line-left pl-6">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Descreva sua Imagem
                </CardTitle>
                <CardDescription>
                  Seja específico e criativo. Cada geração consome 1 crédito.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Ex: Uma mulher sensual em um ambiente futurista neon, iluminação cinematográfica..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={8}
                  className="resize-none bg-background/50"
                  disabled={generateMutation.isPending}
                />
                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending || !prompt.trim() || (credits?.credits ?? 0) < 1}
                  className="w-full h-12 text-lg font-semibold neon-border-pink"
                  size="lg"
                >
                  {generateMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin mr-2" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Gerar Imagem
                    </>
                  )}
                </Button>
                {(credits?.credits ?? 0) < 1 && (
                  <p className="text-sm text-destructive text-center">
                    Você não tem créditos suficientes
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="text-lg">Dicas para Prompts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>• Descreva aparência física, roupas e cenário</p>
                <p>• Mencione estilo artístico (fotorrealista, anime, pintura)</p>
                <p>• Especifique iluminação e atmosfera</p>
                <p>• Use adjetivos descritivos e detalhados</p>
              </CardContent>
            </Card>
          </div>

          {/* Right: Preview */}
          <div className="space-y-6 accent-line-right pr-6">
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>
                  Sua imagem gerada aparecerá aqui
                </CardDescription>
              </CardHeader>
              <CardContent>
                {generateMutation.isPending ? (
                  <div className="aspect-square bg-muted/20 rounded-lg flex items-center justify-center">
                    <div className="text-center space-y-4">
                      <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
                      <p className="text-sm text-muted-foreground">
                        Gerando sua imagem...
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Isso pode levar de 5 a 20 segundos
                      </p>
                    </div>
                  </div>
                ) : generatedImage ? (
                  <div className="space-y-4">
                    <div className="aspect-square rounded-lg overflow-hidden border-2 border-primary/30 neon-border-pink">
                      <img
                        src={generatedImage}
                        alt="Generated content"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => window.open(generatedImage, "_blank")}
                      >
                        Abrir em Nova Aba
                      </Button>
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => {
                          const a = document.createElement("a");
                          a.href = generatedImage;
                          a.download = `nsfw-${Date.now()}.png`;
                          a.click();
                        }}
                      >
                        Download
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="aspect-square bg-muted/20 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                    <div className="text-center space-y-2 p-8">
                      <Sparkles className="w-12 h-12 text-muted-foreground mx-auto" />
                      <p className="text-sm text-muted-foreground">
                        Nenhuma imagem gerada ainda
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
