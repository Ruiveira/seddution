import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Loader2, Image as ImageIcon, Sparkles, Coins } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import type { ImageGeneration } from "../../../drizzle/schema";

export default function Gallery() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedImage, setSelectedImage] = useState<ImageGeneration | null>(null);

  const { data: generations, isLoading } = trpc.generator.history.useQuery(
    { limit: 50 },
    { enabled: !!user }
  );

  const { data: credits } = trpc.credits.get.useQuery(undefined, {
    enabled: !!user,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Autenticação Necessária</CardTitle>
            <CardDescription>
              Você precisa fazer login para ver sua galeria
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              className="w-full"
            >
              Fazer Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl md:text-3xl font-bold neon-glow-cyan">
              Minha Galeria
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-primary/30 neon-border-pink">
              <Coins className="w-5 h-5 text-primary" />
              <span className="font-semibold text-primary">
                {credits?.credits ?? 0}
              </span>
              <span className="text-sm text-muted-foreground">créditos</span>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation("/pricing")}
            >
              Planos
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/generator")}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Gerar Nova
            </Button>
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
            >
              Início
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !generations || generations.length === 0 ? (
          <div className="flex items-center justify-center py-20">
            <Card className="max-w-md w-full text-center">
              <CardHeader>
                <div className="mx-auto w-16 h-16 rounded-full bg-muted/20 flex items-center justify-center mb-4">
                  <ImageIcon className="w-8 h-8 text-muted-foreground" />
                </div>
                <CardTitle>Nenhuma Imagem Ainda</CardTitle>
                <CardDescription>
                  Você ainda não gerou nenhuma imagem. Comece criando sua primeira obra!
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => setLocation("/generator")}
                  className="w-full"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Gerar Primeira Imagem
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {generations.length} {generations.length === 1 ? "imagem" : "imagens"} geradas
              </p>
            </div>

            {/* Gallery Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {generations.map((gen) => (
                <Card
                  key={gen.id}
                  className="group cursor-pointer hover:border-primary/50 transition-all overflow-hidden"
                  onClick={() => setSelectedImage(gen)}
                >
                  <div className="aspect-square overflow-hidden bg-muted/20">
                    <img
                      src={gen.imageUrl}
                      alt="Generated content"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                  </div>
                  <CardContent className="p-3">
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {gen.prompt}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(gen.createdAt).toLocaleDateString("pt-BR", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Image Detail Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedImage && (
            <>
              <DialogHeader>
                <DialogTitle>Detalhes da Imagem</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="rounded-lg overflow-hidden border-2 border-primary/30">
                  <img
                    src={selectedImage.imageUrl}
                    alt="Generated content"
                    className="w-full h-auto"
                  />
                </div>
                <div className="space-y-2">
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground">Prompt:</p>
                    <p className="text-sm">{selectedImage.prompt}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground">Data:</p>
                    <p className="text-sm">
                      {new Date(selectedImage.createdAt).toLocaleString("pt-BR")}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground">Créditos usados:</p>
                    <p className="text-sm">{selectedImage.creditsUsed}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => window.open(selectedImage.imageUrl, "_blank")}
                  >
                    Abrir em Nova Aba
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      const a = document.createElement("a");
                      a.href = selectedImage.imageUrl;
                      a.download = `nsfw-${selectedImage.id}.png`;
                      a.click();
                    }}
                  >
                    Download
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
