import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";

const AGE_VERIFICATION_KEY = "age_verified";

export default function AgeVerification() {
  const [, setLocation] = useLocation();
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    // Check if already verified
    const verified = localStorage.getItem(AGE_VERIFICATION_KEY);
    if (verified === "true") {
      setIsVerified(true);
      setLocation("/");
    }
  }, [setLocation]);

  const handleConfirm = () => {
    localStorage.setItem(AGE_VERIFICATION_KEY, "true");
    setIsVerified(true);
    setLocation("/");
  };

  const handleDecline = () => {
    window.location.href = "https://www.google.com";
  };

  if (isVerified) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-6">
        {/* Warning Banner */}
        <div className="flex items-center justify-center gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
          <AlertTriangle className="w-6 h-6 text-destructive" />
          <p className="text-sm font-semibold text-destructive">
            CONTEÚDO ADULTO - VERIFICAÇÃO DE IDADE OBRIGATÓRIA
          </p>
        </div>

        {/* Main Card */}
        <Card className="border-primary/30 neon-border-pink">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <ShieldAlert className="w-10 h-10 text-primary" />
            </div>
            <CardTitle className="text-3xl neon-glow-pink">
              Verificação de Idade
            </CardTitle>
            <CardDescription className="text-base">
              Este site contém conteúdo adulto gerado por inteligência artificial
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Terms */}
            <div className="space-y-4 p-6 bg-card/50 rounded-lg border border-border/50">
              <h3 className="font-semibold text-lg">Aviso Importante:</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Você deve ter <strong className="text-foreground">18 anos ou mais</strong> para acessar este site</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Todo o conteúdo é <strong className="text-foreground">gerado por IA</strong> e destinado exclusivamente a adultos</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>É <strong className="text-foreground">proibido</strong> gerar conteúdo envolvendo menores de idade ou atividades ilegais</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Você é responsável pelo uso apropriado desta plataforma</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Ao continuar, você concorda com nossos <button onClick={() => setLocation("/terms")} className="text-primary hover:underline">Termos de Uso</button></span>
                </li>
              </ul>
            </div>

            {/* Legal Notice */}
            <div className="p-4 bg-muted/20 rounded-lg border border-border/30">
              <p className="text-xs text-muted-foreground text-center">
                Este site utiliza cookies para verificar sua idade. Ao clicar em "Confirmo que tenho 18+",
                você declara sob pena de lei que possui idade legal para acessar conteúdo adulto em sua jurisdição.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4 pt-4">
              <Button
                variant="outline"
                onClick={handleDecline}
                className="h-12"
              >
                Sou Menor de 18
              </Button>
              <Button
                onClick={handleConfirm}
                className="h-12 neon-border-pink font-semibold"
              >
                Confirmo que tenho 18+
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground">
          Ao acessar este site, você concorda em cumprir todas as leis aplicáveis em sua região
        </p>
      </div>
    </div>
  );
}

// Hook to check age verification
export function useAgeVerification() {
  const [isVerified, setIsVerified] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const verified = localStorage.getItem(AGE_VERIFICATION_KEY);
    if (verified !== "true") {
      setLocation("/age-verification");
    } else {
      setIsVerified(true);
    }
  }, [setLocation]);

  return isVerified;
}
