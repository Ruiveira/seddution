import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Terms() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
        </div>
      </header>

      <main className="container py-8 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl neon-glow-pink">
              Termos de Uso
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Última atualização: {new Date().toLocaleDateString("pt-BR")}
            </p>
          </CardHeader>
          <CardContent className="prose prose-invert max-w-none space-y-6">
            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">1. Aceitação dos Termos</h2>
              <p className="text-muted-foreground">
                Ao acessar e usar o AI NSFW Content Generator, você concorda em cumprir e estar vinculado
                a estes Termos de Uso. Se você não concordar com qualquer parte destes termos, não deve
                usar este serviço.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">2. Restrição de Idade</h2>
              <p className="text-muted-foreground">
                Este serviço é destinado exclusivamente a usuários com 18 anos de idade ou mais. Ao usar
                este site, você declara e garante que tem pelo menos 18 anos de idade e possui capacidade
                legal para celebrar este contrato vinculativo.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">3. Conteúdo Gerado por IA</h2>
              <p className="text-muted-foreground">
                Todo o conteúdo visual gerado nesta plataforma é criado por inteligência artificial.
                As imagens não representam pessoas reais e são puramente fictícias. Você reconhece que:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
                <li>Todo conteúdo é gerado artificialmente</li>
                <li>Nenhuma pessoa real é retratada nas imagens</li>
                <li>As imagens são para uso pessoal e privado</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">4. Uso Proibido</h2>
              <p className="text-muted-foreground">
                Você concorda expressamente em NÃO usar este serviço para:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground ml-4">
                <li>Gerar conteúdo envolvendo menores de idade</li>
                <li>Criar conteúdo que viole leis locais, estaduais ou federais</li>
                <li>Gerar conteúdo não consensual ou que viole direitos de terceiros</li>
                <li>Criar deepfakes ou imagens que se passem por pessoas reais</li>
                <li>Distribuir, vender ou comercializar conteúdo gerado</li>
                <li>Usar o serviço para assédio, intimidação ou atividades ilegais</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">5. Sistema de Créditos</h2>
              <p className="text-muted-foreground">
                O acesso ao serviço de geração de imagens é controlado por um sistema de créditos.
                Cada geração de imagem consome créditos da sua conta. Os créditos não são reembolsáveis
                e não possuem valor monetário.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">6. Propriedade do Conteúdo</h2>
              <p className="text-muted-foreground">
                Você mantém a propriedade das imagens que gera através desta plataforma. No entanto,
                ao usar o serviço, você nos concede uma licença não exclusiva, mundial e livre de
                royalties para armazenar e processar seu conteúdo conforme necessário para fornecer
                o serviço.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">7. Privacidade e Dados</h2>
              <p className="text-muted-foreground">
                Respeitamos sua privacidade. Armazenamos apenas as informações necessárias para fornecer
                o serviço, incluindo seu histórico de gerações e saldo de créditos. Não compartilhamos
                suas imagens geradas com terceiros.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">8. Suspensão e Encerramento</h2>
              <p className="text-muted-foreground">
                Reservamos o direito de suspender ou encerrar sua conta imediatamente, sem aviso prévio,
                se você violar estes Termos de Uso ou se envolvermos em atividades ilegais ou inadequadas.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">9. Isenção de Responsabilidade</h2>
              <p className="text-muted-foreground">
                Este serviço é fornecido "como está" sem garantias de qualquer tipo. Não garantimos que
                o serviço será ininterrupto, seguro ou livre de erros. Você usa este serviço por sua
                própria conta e risco.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">10. Limitação de Responsabilidade</h2>
              <p className="text-muted-foreground">
                Em nenhuma circunstância seremos responsáveis por quaisquer danos diretos, indiretos,
                incidentais, especiais ou consequenciais resultantes do uso ou incapacidade de usar
                este serviço.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">11. Modificações dos Termos</h2>
              <p className="text-muted-foreground">
                Reservamos o direito de modificar estes Termos de Uso a qualquer momento. As alterações
                entrarão em vigor imediatamente após a publicação. Seu uso continuado do serviço após
                as alterações constitui aceitação dos novos termos.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">12. Lei Aplicável</h2>
              <p className="text-muted-foreground">
                Estes Termos de Uso são regidos pelas leis aplicáveis em sua jurisdição. Você é
                responsável por garantir que seu uso deste serviço esteja em conformidade com todas
                as leis locais.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-3">13. Contato</h2>
              <p className="text-muted-foreground">
                Se você tiver dúvidas sobre estes Termos de Uso, entre em contato através da plataforma.
              </p>
            </section>

            <div className="pt-6 border-t border-border/50">
              <p className="text-sm text-muted-foreground italic">
                Ao usar o AI NSFW Content Generator, você reconhece que leu, compreendeu e concorda
                em estar vinculado a estes Termos de Uso.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
