# Guia de Configuração de Pagamentos

Este documento contém as informações necessárias para a criação das contas nas plataformas solicitadas. Como sou um agente de IA, não posso criar contas diretamente em seu nome devido a requisitos de segurança (como verificação de identidade, CAPTCHAs e senhas), mas preparei tudo para facilitar o processo.

## Dados do Titular
- **Nome Completo:** Alan Alves Queiroz
- **Email:** allancqc2012@icloud.com
- **Telefone:** +55 18 9 8117 4695
- **País:** Brasil

---

## 1. Epoch (epoch.com)
A Epoch é uma das maiores processadoras para conteúdo adulto.
- **Ação Necessária:** Acesse [Epoch Merchant Sign-up](https://epoch.com/en/merchants.html).
- **Processo:** Preencha o formulário de "Merchant Application". Eles solicitarão documentos da empresa ou identidade pessoal.
- **Integração:** Após a aprovação, eles fornecerão um `Member ID` e `Product ID` que precisaremos inserir no código.

## 2. CCBill (ccbill.com)
Líder mundial em pagamentos para entretenimento adulto.
- **Ação Necessária:** Acesse [CCBill Sign-up](https://www.ccbill.com/signup.php).
- **Processo:** Escolha a conta de "Merchant". O processo de aprovação pode levar de 2 a 5 dias úteis.
- **Integração:** Precisaremos do seu `Client Account Number` e `Sub-Account Number`.

## 3. Cryptocurrency (Coinbase Commerce ou NOWPayments)
Para aceitar Cripto de forma automatizada.
- **Recomendação:** [NOWPayments](https://nowpayments.io/) (mais fácil para conteúdo adulto).
- **Ação Necessária:** Crie uma conta com seu email.
- **Integração:** Forneceremos uma chave API para gerar endereços de pagamento automáticos.

---

## Próximos Passos
1. **Senhas:** Quando você estiver na tela de criação de senha de qualquer uma dessas plataformas, você pode me informar ou definir uma de sua preferência.
2. **Links de Pagamento:** Assim que as contas forem aprovadas, eu ajudarei a gerar os links específicos para os planos **Pro**, **Platinum** e **Diamond** dentro de cada painel.
3. **Atualização do Código:** Assim que tivermos os links/IDs, atualizarei o componente `Pricing.tsx` para incluir as novas opções de pagamento ao lado do Stripe.

---

## Matriz de Planos Atualizada (Implementada no Código)

| Plano | Mensal | Trimestral | Semestral | Anual |
|-------|--------|------------|-----------|-------|
| **Pro** | R$ 29,90 | R$ 74,90 | R$ 139,90 | R$ 238,80 |
| **Platinum** | R$ 59,90 | R$ 149,90 | R$ 279,90 | R$ 479,90 |
| **Diamond** | R$ 129,90 | R$ 329,90 | R$ 599,90 | R$ 999,90 |

*Nota: Atualmente, todos os botões estão usando temporariamente os links do Stripe fornecidos como fallback.*
