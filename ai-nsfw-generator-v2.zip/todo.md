# AI NSFW Generator - Lista de Tarefas

## Backend & Banco de Dados
- [x] Criar tabela de créditos de usuários no schema
- [x] Criar tabela de gerações de imagens no schema
- [x] Implementar sistema de créditos (adicionar, consumir, verificar saldo)
- [x] Criar procedimento tRPC para verificar créditos do usuário
- [x] Criar procedimento tRPC para gerar imagem NSFW
- [x] Criar procedimento tRPC para listar histórico de gerações
- [x] Integrar com API de geração de imagens via generateImage helper
- [x] Implementar upload de imagens geradas para S3
- [x] Adicionar lógica de consumo de créditos ao gerar imagem

## Frontend - Estética Neon-Noir
- [x] Configurar tema dark com paleta neon-noir (midnight navy, hot pink, cyan, magenta)
- [x] Adicionar fontes Google Fonts adequadas (sans-serif ousada + elegante)
- [x] Criar estilos globais com efeitos de brilho neon em index.css
- [x] Implementar linhas verticais minimalistas de destaque

## Páginas & Componentes
- [x] Criar página de verificação de idade (AgeVerification.tsx)
- [x] Criar página de termos de uso (Terms.tsx)
- [x] Criar página principal de geração (Generator.tsx)
- [x] Criar página de galeria pessoal (Gallery.tsx)
- [x] Criar componente de exibição de créditos do usuário
- [x] Criar formulário de prompt para geração de imagens
- [x] Criar componente de preview de imagem gerada
- [x] Implementar grid responsivo para galeria

## Autenticação & Navegação
- [x] Configurar rotas protegidas que requerem autenticação
- [x] Adicionar verificação de idade antes do acesso ao conteúdo
- [x] Implementar navegação entre páginas (Home, Generator, Gallery)
- [x] Adicionar header com logout e exibição de créditos

## Funcionalidades de Geração
- [x] Implementar campo de prompt de texto
- [x] Adicionar botão de geração com loading state
- [x] Exibir imagem gerada após conclusão
- [x] Mostrar mensagem de erro se créditos insuficientes
- [x] Adicionar opção de download da imagem
- [x] Salvar geração no histórico do usuário

## Sistema de Créditos
- [x] Dar créditos iniciais ao novo usuário (ex: 10 créditos)
- [x] Consumir 1 crédito por geração de imagem
- [x] Exibir saldo de créditos em tempo real
- [x] Bloquear geração quando créditos = 0
- [x] Adicionar página/modal explicando sistema de créditos

## Testes
- [x] Escrever testes vitest para sistema de créditos
- [ ] Escrever testes vitest para geração de imagens
- [ ] Testar fluxo completo de verificação de idade
- [ ] Testar integração com S3

## Finalização
- [x] Revisar todos os componentes e estilos
- [x] Verificar responsividade mobile
- [x] Criar checkpoint final
- [x] Documentar funcionalidades para o usuário
